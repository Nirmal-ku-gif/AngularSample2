import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  // name="belly"
  // address="kochi"
  constructor() { }

  ngOnInit(): void {
  }
isAvailable=false;

//array
// day=["sunday","monday","tuesady","wednesday","thursday","friday","saturday"];

// phones=["Iphone","Nokia","OPPO"];

// Number=[1,2,3,4,5,6,7,8,9,10];

// Numbers=[1,2,3,4,6];
//variable  using let
 letters = ["a", "b", "c", "d", "e", "f"];
}
